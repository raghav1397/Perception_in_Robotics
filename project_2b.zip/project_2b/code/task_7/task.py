
import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d import axes3d, Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection, Line3DCollection

img_l = cv.imread('../../images/task_7/left_0.png')
img_r = cv.imread('../../images/task_7/left_1.png')
img_shape = img_l.shape[::-1]

img_l = cv.cvtColor(img_l, cv.COLOR_BGR2GRAY)
img_r= cv.cvtColor(img_r, cv.COLOR_BGR2GRAY)

M1=np.loadtxt('../../parameters/K_matrix_left')
M2=np.loadtxt('../../parameters/K_matrix_right')

d1=np.loadtxt('../../parameters/distortion_coeffs_left')
d2=np.loadtxt('../../parameters/distortion_coeffs_right')

height,width = img_l.shape[:2]
mapx1, mapy1 = cv.initUndistortRectifyMap(M1, d1, None, M1, (width,height), 5)
remapped_img1 = cv.remap(img_l,mapx1, mapy1, cv.INTER_LINEAR)

mapx2, mapy2 = cv.initUndistortRectifyMap(M1, d1, None, M1, (width,height), 5)
remapped_img2 = cv.remap(img_r,mapx2, mapy2, cv.INTER_LINEAR)

detector = cv.ORB_create(nfeatures=350,scoreType=cv.ORB_FAST_SCORE)

feature_l, descriptor_l = detector.detectAndCompute(remapped_img1,None)
feature_r, descriptor_r = detector.detectAndCompute(remapped_img2,None)

bf = cv.BFMatcher(cv.NORM_HAMMING, crossCheck=True)

matches = bf.match(descriptor_l,descriptor_r)
img_matches_all = cv.drawMatches(remapped_img1,feature_l,remapped_img2,feature_r,matches,remapped_img1)

cv.imshow('feature_matched_images', img_matches_all)
cv.waitKey(1000)
cv.destroyAllWindows()
cv.imwrite("../../output/task_7/feature_matched_images_left_0_1.png", img_matches_all)

list_left = []
list_right= []

points1, points2 = [], []
for match in matches:
    points1.append(feature_l[match.queryIdx].pt)
    points2.append(feature_r[match.trainIdx].pt)

points1=np.array(points1)
points2=np.array(points2)
E, mask = cv.findEssentialMat(points1,points2,M1)
ret_matches=[]
for mask, match in zip(mask, matches):
    if mask[0] > 0:
        ret_matches.append(match)

pts1 = []
pts2 = []
for match in ret_matches:
    pts1.append(feature_l[match.queryIdx].pt)
    pts2.append(feature_r[match.trainIdx].pt)

img_matches = cv.drawMatches(remapped_img1,feature_l,remapped_img2,feature_r,ret_matches,remapped_img1)
pts1=np.array(pts1)
pts2=np.array(pts2)

cv.imshow('reduced_matches_img', img_matches)
cv.waitKey(1000)
cv.destroyAllWindows()
cv.imwrite("../../output/task_7/reduced_matches_images_left_0_1.png", img_matches)

points, R, t, mask_RP = cv.recoverPose(E, pts1, pts2)
t=t*10
I=np.eye(3, 3)
O=np.zeros((3, 1))
Pose_1 = np.hstack((I,O))

Pose_2 = np.hstack((R, t))
P_l = np.dot(M1,Pose_1)
P_r = np.dot(M1,Pose_2)
tp = cv.triangulatePoints(P_l, P_r,pts1.T,pts2.T)
tp=tp*10


def plot_camera(ax, R, T, idx):
    
    H = np.append(np.hstack((R, T)), [[0, 0, 0, 1]], axis=0)

    vertex = np.array([[-1, -1, -1], [1, -1, -1], [1, 1, -1],  [-1, 1, -1], [0, 0, 0]])
    vertex = vertex.T
    vertex = np.append(vertex, [[1, 1, 1, 1, 1]], axis=0)
    vertex_t = (np.matrix(H) * np.matrix(vertex))
    vertex_t = np.delete(vertex_t, 3, 0)
    vertex = np.array(vertex_t.T)
    vertices = [
             [vertex[0], vertex[1], vertex[4]], 
             [vertex[0], vertex[3], vertex[4]],
             [vertex[2], vertex[1], vertex[4]], 
             [vertex[2], vertex[3], vertex[4]], 
             [vertex[0], vertex[1], vertex[2], vertex[3]]
            ]
    ax.text(vertex[4, 0], vertex[4, 1], vertex[4, 2], idx, color='green')
    ax.add_collection3d(Poly3DCollection(vertices, facecolors='white', linewidths=1, edgecolors='k', alpha=.25))

fig = plt.figure()
ax = plt.axes(projection='3d')
ax.set_xlim(15,-15)
ax.set_ylim(-10,10)
ax.set_zlim(-35,5)
ax.set_xlabel('X axis')
ax.set_ylabel('Y axis')
ax.set_zlabel('Z axis')
ax.scatter3D(tp[0]/tp[3], tp[1]/tp[3], tp[2]/tp[3], c='b', marker='o')
plot_camera(ax,I,O,0)
plot_camera(ax,R.T, -np.dot(R.T, t),1)
plt.savefig("../../output/task_7/recovered_pose_recons_camera.png")
plt.show()
