
import cv2 as cv
import numpy as np
import glob
import matplotlib.pyplot as plt

def planar_homography(img_distorted_, img_undistorted_, img_planar_homo_out_, K_matrix, distortion_coeffs, side):

    rows = 9
    cols = 6

    img = cv.imread(img_distorted_)

    h, w = img.shape[:2]

    mapx, mapy = cv.initUndistortRectifyMap(K_matrix, distortion_coeffs, None, K_matrix, (w,h), 5)

    dst = cv.remap(img, mapx, mapy, cv.INTER_LINEAR)

    if dst[0].size > 0:
        cv.imwrite(img_undistorted_, dst)
    else:
        print('image zero')

    # Object points scaled and shifted origin
    objp = np.zeros((rows * cols, 2), np.float32)
    objp[:, :2] = np.mgrid[0:rows, 0:cols].T.reshape(-1, 2) * 10
    origin_shift = np.repeat(np.array([[300, 800]]), 54, axis = 0)


    image = cv.imread(img_undistorted_)
    img = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

    ret, corners = cv.findChessboardCorners(img, (rows, cols), None)
    if ret == True:
        corners2 = cv.cornerSubPix(img, corners, (5,5), (-1,-1), (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_COUNT, 30, 0.01))
        img = cv.drawChessboardCorners(image, (rows, cols), corners2, ret)
        img_undistorted_corners = img_undistorted_.replace('.png', '_w_corners.png')
        cv.imwrite(img_undistorted_corners, np.array(img))

    corners = np.array(corners).reshape(54, 2)
    objectPts = objp + origin_shift

    corners_4 = np.array([corners[0], corners[7], corners[45], corners[53]])
    objectPts_4 = np.array([objectPts[0], objectPts[7], objectPts[45], objectPts[53]])

    h, status = cv.findHomography(corners_4, objectPts_4)
    print("H matrix:" + side)
    print(h)
    im_out = cv.warpPerspective(img, h,(1000, 1000))
    cv.imwrite(img_planar_homo_out_, im_out)

    cv.imshow('planar homography image', np.array(im_out))
    cv.waitKey(1000)
    cv.destroyAllWindows()


K_matrix_left = np.loadtxt("../../parameters/K_matrix_left")
K_matrix_right = np.loadtxt("../../parameters/K_matrix_right")
distortion_coeffs_left = np.loadtxt("../../parameters/distortion_coeffs_left")
distortion_coeffs_right = np.loadtxt("../../parameters/distortion_coeffs_right")

# Left0
img_distorted_ = '../../images/task_5/left_0.png'
img_undistorted_ = '../../output/task_5/left_0_undistorted.png'
img_planar_homo_out_ = '../../output/task_5/left_0_homoplanar.png'
planar_homography(img_distorted_, img_undistorted_, img_planar_homo_out_, K_matrix_left, distortion_coeffs_left, 'left')

# Right0
img_distorted_ = '../../images/task_5/right_0.png'
img_undistorted_ = '../../output/task_5/right_0_undistorted.png'
img_planar_homo_out_ = '../../output/task_5/right_0_homoplanar.png'

planar_homography(img_distorted_, img_undistorted_, img_planar_homo_out_, K_matrix_right, distortion_coeffs_right, 'right')
