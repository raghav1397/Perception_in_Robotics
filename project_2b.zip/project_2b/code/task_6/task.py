
import re
import uuid
import glob
import cv2 as cv
from cv2 import aruco
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d, Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection, Line3DCollection

K_left = np.loadtxt('../../parameters/K_matrix_left')
dist_left = dist_left = np.loadtxt('../../parameters/distortion_coeffs_left')

def atoi(text):
    return int(text) if text.isdigit() else text

def natural_keys(text):
    return [ atoi(c) for c in re.split(r'(\d+)', text) ]


def plot_camera_face(ax):
    side_pts = np.array([[0, 5, 0], [5, 5, 0], [5, 0, 0], [0, 0, 0]])
    side_pts = [[side_pts[0], side_pts[1], side_pts[2], side_pts[3]]]
    point = np.array([[0, 1, 0], [1, 1, 0], [1, 0, 0], [0, 0, 0]])
    point = [[point[0], point[1], point[2], point[3]]]
    ax.add_collection3d(Poly3DCollection(side_pts, facecolors='black', linewidths=1, edgecolors='k', alpha=.5))
    ax.add_collection3d(Poly3DCollection(point, facecolors='blue', linewidths=1, edgecolors='r', alpha=1))


def plot_camera(R, T, side, idx, ax):
    
    H = np.append(np.hstack((R, T)), [[0, 0, 0, 1]], axis=0)

    vertex = np.array([[-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1], [0, 0, 0]])
    vertex = vertex.T
    vertex = np.append(vertex, [[1, 1, 1, 1, 1]], axis=0)
    vertex_t = (np.matrix(H) * np.matrix(vertex))
    vertex_t = np.delete(vertex_t, 3, 0)
    vertex = np.array(vertex_t.T)
    vertices = [
             [vertex[0], vertex[1], vertex[4]], 
             [vertex[0], vertex[3], vertex[4]],
             [vertex[2], vertex[1], vertex[4]], 
             [vertex[2], vertex[3], vertex[4]], 
             [vertex[0], vertex[1], vertex[2], vertex[3]]
            ]
    ax.text(vertex[4, 0], vertex[4, 1], vertex[4, 2], side[0].upper() + str(idx), color='green')
    ax.add_collection3d(Poly3DCollection(vertices, facecolors='white', linewidths=1, edgecolors='k', alpha=.25))


def aruco_detection(img_name, side, idx, ax):
    img = cv.imread(img_name)
    gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
    aruco_dict = aruco.Dictionary_get(aruco.DICT_6X6_250)
    parameters = aruco.DetectorParameters_create()
    corners, ids, rejectedImgPoints = aruco.detectMarkers(img, aruco_dict)
    img_markers = aruco.drawDetectedMarkers(img, corners, ids)
    cv.imshow('img_markers' + img_name, img_markers)
    cv.imwrite('../../output/task_6/aruco_marker_detected_' + side + str(idx) + '.png', img_markers)
    cv.waitKey(1000)
    cv.destroyAllWindows()
    img_points = np.array(corners).reshape(4,2)
    obj_points = np.float32([[0.0,0.0,0.0],[1.0,0.0,0.0],[1.0,1.0,0.0],[0.0,1.0,0.0]])

    retval, rvec, tvec = cv.solvePnP(obj_points, img_points, K_left, dist_left)
    rvec, J = cv.Rodrigues(rvec)
    tvec = (-np.matrix(rvec).T * np.matrix(tvec)*5)
    rvec = rvec.T

    print("-----------Verifying R and T for "+ side + str(idx) +"---------------------")
    print(rvec)
    print(tvec)

    plot_camera(rvec, tvec, side, idx, ax)

# MAIN function

fig = plt.figure()
plt.axis('equal')

ax = plt.axes(projection='3d')
plt.title('Pose Of The Camera')
ax.set_xlim(-18, 18)
ax.set_ylim(18, -18)
ax.set_zlim(18, -18)
ax.set_xlabel('X axis')
ax.set_ylabel('Y axis')
ax.set_zlabel('Z axis')
plot_camera_face(ax)

images_glob = glob.glob('../../images/task_6/left*.png')
images_glob.sort(key=natural_keys)
# print(images_glob)
for idx, img_name in enumerate(images_glob, 0):
    print(img_name)
    aruco_detection(img_name, 'left', idx, ax)
plt.show()
plt.draw()
fig.savefig('../../output/task_6/camera_pose_output.png')
