#!/usr/bin/env python
from __future__ import print_function
import sys
import rospy
import cv2
from std_msgs.msg import String
from sensor_msgs.msg import Image, RegionOfInterest
import imutils
from imutils.object_detection import non_max_suppression
from imutils import paths
import numpy as np
from cv_bridge import CvBridge, CvBridgeError
import message_filters

class HumanDetector:

    def __init__(self):
        self.topic_1 = "/tb3_0/camera/rgb/image_raw"
        self.topic_2 = 'roi'
        self.topic_3 = '/tb3_0/draw_bounding_box'
        self.image_sub = rospy.Subscriber(self.topic_1,Image,self.callback)
        self.roi_pub = rospy.Publisher(self.topic_2, String, queue_size = 20)
        self.detection_pub = rospy.Publisher(self.topic_3, Image, queue_size = 20)
        self.bridge = CvBridge()
        self.frame_count = 0

    def callback(self,data):
        if self.frame_count % 10 == 0:
            try:
                cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
            except CvBridgeError as e:
                rospy.loginfo(e)
            self.frame_count += 1
            hog = cv2.HOGDescriptor()
            hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
            image = imutils.resize(cv_image, width=min(400, cv_image.shape[1]))
            orig = cv_image.copy()
            (rects, weights) = hog.detectMultiScale(image, winStride=(4, 4),padding=(8, 8), scale=1.05)
            for (x, y, w, h) in rects:
                cv2.rectangle(orig, (x, y), (x + w, y + h), (0, 0, 255), 2)
            rects = np.array([[x, y, x + w, y + h] for (x, y, w, h) in rects])
            if len(rects) > 0:
                pick = non_max_suppression(rects, probs=None, overlapThresh=0.65)
                for (xA, yA, xB, yB) in pick:
                    cv2.rectangle(image, (xA, yA), (xB, yB), (0, 255, 0), 2)
                xA, yA, xB, yB = pick[0]
                centroid_x = (xA + xB) / 2.0
                centroid_y = (yA + yB) / 2.0
                height = yB - yA
                width = xB - xA
                roi_msg = "" + str(xA) + " " + str(yA) + " " + str(height) + " " + str(width)
                self.roi_pub.publish(roi_msg)
                self.detection_pub.publish(self.bridge.cv2_to_imgmsg(image, "bgr8"))
            else:
                roi_msg = "" + str(0) + " " + str(0) + " " + str(0) + " " + str(0)
                self.roi_pub.publish(roi_msg)
                
            
        else:
            self.frame_count += 1


    
def main():
        rospy.init_node('HumanDetector', anonymous=True)
        HumanDetector()
        try:
            rospy.spin()
        except KeyboardInterrupt:
            print("Shut down initiated")
        cv2.destroyAllWindows()

if __name__ == '__main__':
        main()
 
