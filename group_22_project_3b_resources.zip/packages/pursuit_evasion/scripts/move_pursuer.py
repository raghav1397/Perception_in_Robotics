#!/usr/bin/env python

import rospy
from sensor_msgs.msg import Image, RegionOfInterest, CameraInfo
from geometry_msgs.msg import Twist
from std_msgs.msg import String
from math import copysign, isnan
import cv2 as cv
from cv_bridge import CvBridge, CvBridgeError
import numpy as np
import thread


class PursueHuman():


    def __init__(self):
        rospy.init_node("Evader_Pursuer")
        rospy.on_shutdown(self.shutdown)
        self.rate = 10
        r = rospy.Rate(self.rate)
        
        self.start_time = rospy.get_rostime()
        self.cv_bridge = CvBridge()
        self.depth_array = None
        self.is_target_visible = False
        
        self.scale_roi = 1.0
        self.max_z = 2.5
        self.min_z = 1.5
        self.goal_z = 1.0
        self.z_scale = 1.0
        self.x_scale = 1.0
        self.max_linear_speed =  0.7
        self.min_linear_speed =  0.2
        self.max_rotation_speed = 0.8
        self.min_rotation_speed = 0.3
        self.x_threshold = 0.8
        self.z_threshold = 0.8
        
        self.slow_down_factor = 0.15
        self.topic_1 = '/tb3_0/cmd_vel'
        self.cmd_vel_pub = rospy.Publisher(self.topic_1, Twist, queue_size=5)
        self.move_cmd = Twist()
        self.lock = thread.allocate_lock()
        self.image_width = 0
        self.image_height = 0
        
        # camera topics
        rospy.loginfo("Loading camera info...")
        self.topic_2 = '/tb3_0/camera/rgb/camera_info'
        rospy.wait_for_message(self.topic_2, CameraInfo)
        rospy.Subscriber(self.topic_2, CameraInfo, self.get_camera_info, queue_size=1)
        
        
        while self.image_width == 0 or self.image_height == 0:
            rospy.sleep(1)
        
        # camera depth topics
        rospy.loginfo("Loading depth image topic...")
        self.topic_3 = '/tb3_0/camera/depth/image_raw'
        rospy.wait_for_message(self.topic_3, Image)
        self.depth_subscriber = rospy.Subscriber(self.topic_3, Image, self.convert_depth_image, queue_size=1)
        
        # ROI published as String
        rospy.loginfo("Loading ROI Strings...")
        self.topic_4 = '/roi'
        rospy.Subscriber(self.topic_4, String, self.set_cmd_vel, queue_size=1)
        rospy.wait_for_message(self.topic_4, String)
        
        rospy.loginfo("Got topic messages. Starting pursuer")
        
        while not rospy.is_shutdown():
            self.lock.acquire()
            
            try:
                if not self.is_target_visible:
                    self.move_cmd.linear.x = self.max_linear_speed
                    self.move_cmd.angular.z *= self.slow_down_factor
                else:
                    self.is_target_visible = False
                    
                self.cmd_vel_pub.publish(self.move_cmd)
                    
            finally:
                self.lock.release()
            r.sleep()
            
            
    def convert_depth_image(self, ros_image):
        try:
            depth_image = self.cv_bridge.imgmsg_to_cv2(ros_image, "passthrough")
        except CvBridgeError as e:
            print(e)
        self.depth_array = np.array(depth_image, dtype=np.float32)
        
        
    def get_camera_info(self, msg):
        self.image_width = msg.width
        self.image_height = msg.height
        
        
    def shutdown(self):
        rospy.loginfo("Pursuer terminating..")
        self.depth_subscriber.unregister()
        # rospy.sleep(1)
        self.cmd_vel_pub.publish(Twist())
        # rospy.sleep(1) 
        rospy.signal_shutdown("5 minutes up! Shutting down nodes.. Bye!")
        
                        
    def set_cmd_vel(self, msg):
        if rospy.get_rostime().secs - self.start_time.secs > 300:
            self.shutdown()
        rospy.loginfo("Time since startup (in seconds): " + str(rospy.get_rostime().secs - self.start_time.secs))
        self.lock.acquire()
        params = ['x_offset', 'y_offset', 'height', 'width']
        msg = dict({k:float(m) for k,m in zip(params, str(msg.data).split(" "))})
        try:
            if msg['width'] == 0 or msg['height'] == 0:
                self.is_target_visible = False
                return
            else:
                self.is_target_visible = True
    
            self.roi = msg
                        
            target_offset_x = msg['x_offset'] + msg['width'] / 2 - self.image_width / 2
    
            try:
                percent_offset_x = float(target_offset_x) / (float(self.image_width) / 2.0)
            except:
                percent_offset_x = 0
            if abs(percent_offset_x) > self.x_threshold:
                speed = percent_offset_x * self.x_scale
                self.move_cmd.angular.z = -copysign(self.min_rotation_speed, speed)
            else:
                self.move_cmd.angular.z = 0
                
            
            n_z = sum_z = mean_z = 0
             
            scaled_width = int(self.roi['width'] * self.scale_roi)
            scaled_height = int(self.roi['height'] * self.scale_roi)
            
            min_x = int(self.roi['x_offset'] + self.roi['width'] * (1.0 - self.scale_roi) / 2.0)
            max_x = min_x + scaled_width
            min_y = int(self.roi['y_offset'] + self.roi['height'] * (1.0 - self.scale_roi) / 2.0)
            max_y = min_y + scaled_height
            
            for x in range(min_x, max_x):
                for y in range(min_y, max_y):
                    try:
                        z = self.depth_array[y, x]
                        
                        if isnan(z):
                            continue
                                                   
                    except:
                        z = 0
                        
                    if z > 100:
                        z /= 1000.0
                        
                    if z > self.max_z:
                        continue
                    
                    sum_z = sum_z + z
                    n_z += 1
                    
            linear_x = 0
            
            if n_z:
                mean_z = float(sum_z) / n_z
                                                                                                
                mean_z = max(self.min_z, mean_z)
                                                        
                if mean_z > self.min_z:
                    if mean_z < self.max_z and (abs(mean_z - self.goal_z) > self.z_threshold):
                        speed = (mean_z - self.goal_z) * self.z_scale
                        linear_x = copysign(min(self.max_linear_speed, max(self.min_linear_speed, abs(speed))), speed)
            if linear_x == 0:
                self.move_cmd.linear.x *= self.slow_down_factor
            else:
                self.move_cmd.linear.x = linear_x
        finally:
            self.lock.release()
         
         
if __name__ == '__main__':
    try:
        PursueHuman()
        rospy.spin()
    except rospy.ROSInterruptException:
        rospy.loginfo("Pursuer terminated!")