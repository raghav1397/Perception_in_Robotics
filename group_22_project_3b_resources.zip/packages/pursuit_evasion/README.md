
# Pre-requsites

1) Install all Tb3 packages
2) sudo apt install ros-melodic-slam-gmapping

# Gmapping with Turtlebot3

## Launch the world and gmapping package

1) roslaunch pursuit_evasion robot_mapping.launch

## To drive autonomously with Turtlebot3 to map(not suggested)

2) roslaunch turtlebot3_gazebo turtlebot3_simulation.launch

## Using teleop to move around and create map

2) roslaunch turtlebot3_teleop turtlebot3_teleop_key.launch

## Saving the created map

3) rosrun map_server map_saver -f ~/map

## Steps to run the submission

Steps to run:

1.Launch RViz using command
roslaunch pursuit_evasion robot_amcl.launch map_file:=/home/haseeb/catkin_ws/src/pursuit_evasion/maps/Environment_0_map/maps.yaml world_index:=0
2.Run Image_detector
python image_detector.py
3.Start the turtle bot to pursue the human
python2 move_pursuer.py
4.Start the human evader
python move_evader.py
